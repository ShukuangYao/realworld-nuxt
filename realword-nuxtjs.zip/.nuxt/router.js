import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _d57f43d4 = () => interopDefault(import('../pages/layout' /* webpackChunkName: "" */))
const _312a22cb = () => interopDefault(import('../pages/home' /* webpackChunkName: "" */))
const _175b0206 = () => interopDefault(import('../pages/login' /* webpackChunkName: "" */))
const _02d5843d = () => interopDefault(import('../pages/profile' /* webpackChunkName: "" */))
const _2dc9d7e2 = () => interopDefault(import('../pages/settings' /* webpackChunkName: "" */))
const _ed1cf74e = () => interopDefault(import('../pages/editor' /* webpackChunkName: "" */))
const _2cc070ec = () => interopDefault(import('../pages/article' /* webpackChunkName: "" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _d57f43d4,
    children: [{
      path: "",
      component: _312a22cb,
      name: "home"
    }, {
      path: "/login",
      component: _175b0206,
      name: "login"
    }, {
      path: "/register",
      component: _175b0206,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _02d5843d,
      name: "profile"
    }, {
      path: "/settings",
      component: _2dc9d7e2,
      name: "settings"
    }, {
      path: "/editor",
      component: _ed1cf74e,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _2cc070ec,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
